# 🖥️ Kingsman Update Server

## 📋 Servidor de Atualizações
Servidor HTTP para distribuição de atualizações do Kingsman Menu.

## 🚀 Instalação
1. Extrair arquivos do servidor
2. Executar `start_server.bat` (Windows) ou `start_server.sh` (Linux)
3. Acessar http://localhost:8000

## 📡 Funcionalidades
- ✅ API de versões JSON
- ✅ Distribuição de patches
- ✅ Interface web administrativa
- ✅ Log de downloads
- ✅ Estatísticas de uso

## 🔧 Configuração
Edite `server_config.json` para personalizar:
- Porta do servidor
- Diretório de arquivos
- Configurações de log
- URLs de API

## 📊 Endpoints
- `/api/latest.json` - Informações da versão atual
- `/patches/` - Diretório de patches
- `/downloads/` - Arquivos para download
