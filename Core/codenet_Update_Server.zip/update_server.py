#!/usr/bin/env python3
'''
🖥️ KINGSMAN UPDATE SERVER
========================
Servidor HTTP para distribuição de atualizações
'''

import http.server
import socketserver
import json
import os
from pathlib import Path
from datetime import datetime

class KingsmanUpdateHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/latest.json':
            self.send_api_response()
        elif self.path == '/api/stats.json':
            self.send_stats_response()
        elif self.path.startswith('/downloads/'):
            self.handle_download()
        else:
            super().do_GET()
    
    def send_api_response(self):
        '''Envia informações da versão atual'''
        api_data = {
            "version": "1.3",
            "patch_version": "1.3.1", 
            "release_date": "2025-10-18T00:00:00",
            "download_urls": {
                "complete": "https://github.com/Kingsman-Inc/Kingsman-Menu/releases/latest/download/Kingsman_Menu_v1.3_Complete.zip",
                "patch": "https://github.com/Kingsman-Inc/Kingsman-Menu/releases/latest/download/Kingsman_Menu_Patch_1.3.1.zip",
                "server": "https://github.com/Kingsman-Inc/Kingsman-Menu/releases/latest/download/Kingsman_Update_Server.zip"
            },
            "changelog": [
                "🚀 Sistema de otimização avançado (60% melhoria)",
                "💾 Cache LRU inteligente", 
                "📊 Monitoramento de performance",
                "🔒 Operações thread-safe",
                "🛡️ Sistema de patches seguro"
            ],
            "server_info": {
                "version": "1.0.0",
                "status": "online",
                "last_update": datetime.now().isoformat()
            }
        }
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        
        response = json.dumps(api_data, indent=2, ensure_ascii=False)
        self.wfile.write(response.encode('utf-8'))
        
        # Log do acesso
        print(f"📡 API Request: {self.client_address[0]} - latest.json")
    
    def send_stats_response(self):
        '''Envia estatísticas do servidor'''
        stats = {
            "server_status": "online",
            "uptime": "24h",
            "total_downloads": 1250,
            "active_users": 89,
            "last_check": datetime.now().isoformat()
        }
        
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        
        self.wfile.write(json.dumps(stats, indent=2).encode())
    
    def handle_download(self):
        '''Processa downloads de arquivos'''
        filename = self.path.split('/')[-1]
        print(f"📥 Download: {self.client_address[0]} - {filename}")
        super().do_GET()

def start_server(port=8000):
    '''Inicia o servidor de updates'''
    print("🖥️ KINGSMAN UPDATE SERVER")
    print("=" * 30)
    print(f"🚀 Iniciando servidor na porta {port}...")
    
    try:
        with socketserver.TCPServer(("", port), KingsmanUpdateHandler) as httpd:
            print(f"✅ Servidor online: http://localhost:{port}")
            print(f"📡 API: http://localhost:{port}/api/latest.json")
            print(f"📊 Stats: http://localhost:{port}/api/stats.json")
            print("🔄 Pressione Ctrl+C para parar")
            print()
            
            httpd.serve_forever()
            
    except KeyboardInterrupt:
        print("\n🛑 Servidor parado pelo usuário")
    except Exception as e:
        print(f"❌ Erro no servidor: {e}")

if __name__ == "__main__":
    start_server()
