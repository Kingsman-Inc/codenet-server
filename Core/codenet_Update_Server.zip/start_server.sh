#!/bin/bash
echo "🖥️ KINGSMAN UPDATE SERVER"
echo "========================="
echo "🚀 Iniciando servidor..."

python3 update_server.py
